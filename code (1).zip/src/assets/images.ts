// Do not edit manually

export const IMAGES = {
  NICOLAS_MORENO_2: "/images/Nicolas moreno.jpeg",
  NICOLAS_MORENO_4: "/images/Nicolas moreno.jpeg",
  SOFIA_OSORIO_JPG_1: "/images/Sofia Osorio Jpg.jpeg",
  SOFIA_OSORIO_JPG_3: "/images/Sofia Osorio Jpg.jpeg",
} as const;

export type ImageKey = keyof typeof IMAGES;
